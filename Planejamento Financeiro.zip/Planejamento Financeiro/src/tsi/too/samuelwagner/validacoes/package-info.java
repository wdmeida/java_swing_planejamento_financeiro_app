/**
 * Este pacote cont�m as classes com os m�todos respons�veis por validar as entradas de dados do 
 * usu�rio e as fun��es auxiliares utilizadas no aplicativo Planejamento Financeiro.
 * 
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.validacoes;