package tsi.too.samuelwagner.gui;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.TitledBorder;

import tsi.too.samuelwagner.enumeracoes.TituloJanela;
import tsi.too.samuelwagner.operacoes.GeraGraficoCategoria;
import tsi.too.samuelwagner.operacoes.OperacoesDoIgPlanejamentoFinanceiro;
/**
 * A classe <code>IgGraficoBarra</code> � respons�vel por construir o gr�fico de barras de exibi��o das despesas.
 * @author Wagner Almeida.
 * @author Samuel Gon�alves.
 *
 */
public class IgGraficoBarra extends JDialog {
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPanel panelGraficoMetaMesal;
	private GeraGraficoCategoria geraGraficoCategoria;
	private JComboBox<String> mesAnoComboBox;
	private JRadioButton graficoValorRadio;
	private JRadioButton graficoPorcentagemRadio;
	private static Color corPainel = new Color(248, 248, 248);
	
	/**
	 * Construtor da classe <code>IgGraficoBarra</code>. Constr�i a interface gr�fica para exibi��o do gr�fico de 
	 * barra de exibi��o das categorias.
	 * @param igPlanejamentoFinanceiro <code>IgPlanejamentoFinanceiro</code> com a refer�ncia da janela principal.
	 * @param tituloJanela <code>TituloJanela</code> com o t�tulo da janela.
	 */
	public IgGraficoBarra(IgPlanejamentoFinanceiro igPlanejamentoFinanceiro,TituloJanela tituloJanela) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(IgCadastrarDespesas.class.getResource("/tsi/too/samuelwagner/imagens/bars graphic4.png")));
		getContentPane().setBackground(corPainel);
		getContentPane().setLayout(null);
		
		panelGraficoMetaMesal = new JPanel();
		panelGraficoMetaMesal.setBackground(corPainel);
		panelGraficoMetaMesal.setBorder(new TitledBorder(null, "Grafico Categorias", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelGraficoMetaMesal.setBounds(10, 64, 925, 411);
		getContentPane().add(panelGraficoMetaMesal);
		panelGraficoMetaMesal.setLayout(null);
		geraGraficoCategoria = new GeraGraficoCategoria(IgGraficoBarra.this);
		
		
		JPanel radioPanel = new JPanel();
		radioPanel.setBackground(corPainel);
		radioPanel.setBorder(new TitledBorder(null, "Escolha o Tipo de Gr\u00E1fico:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		radioPanel.setBounds(217, 11, 342, 53);
		getContentPane().add(radioPanel);
		radioPanel.setLayout(null);
		
		graficoValorRadio = new JRadioButton("Gr\u00E1fico Valor");
		graficoValorRadio.setBackground(corPainel);
		graficoValorRadio.setMnemonic(KeyEvent.VK_V);
		buttonGroup.add(graficoValorRadio);
		graficoValorRadio.setBounds(202, 19, 134, 23);
		radioPanel.add(graficoValorRadio);
		
		graficoPorcentagemRadio = new JRadioButton("Gr\u00E1fico Porcentagem");
		graficoPorcentagemRadio.setBackground(corPainel);
		graficoPorcentagemRadio.setMnemonic(KeyEvent.VK_P);
		buttonGroup.add(graficoPorcentagemRadio);
		graficoPorcentagemRadio.setBounds(18, 19, 182, 23);
		radioPanel.add(graficoPorcentagemRadio);
		
		JPanel comboBoxPanel = new JPanel();
		comboBoxPanel.setBackground(corPainel);
		comboBoxPanel.setBorder(new TitledBorder(null, "Escolha o M\u00EAs:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		comboBoxPanel.setBounds(10, 11, 197, 53);
		getContentPane().add(comboBoxPanel);
		comboBoxPanel.setLayout(null);
		
		mesAnoComboBox = new JComboBox<String>(OperacoesDoIgPlanejamentoFinanceiro.preencheMesAnteriorDespesa());
		mesAnoComboBox.setBounds(10, 20, 177, 22);
		
		graficoPorcentagemRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				atualizaGrafico();
			}
		});
		
		graficoValorRadio.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				atualizaGrafico();
			}
		});
		
		mesAnoComboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				atualizaGrafico();
			}
		});
		
		graficoValorRadio.setSelected(true);
		panelGraficoMetaMesal.add(geraGraficoCategoria.geraGraficoBarra(mesAnoComboBox.getItemAt(mesAnoComboBox.getSelectedIndex()), false));
		
		comboBoxPanel.add(mesAnoComboBox);
		setModal(true);
		setTitle(tituloJanela.getTitulo());
		setBounds(100, 100, 951, 511);
		setResizable(false);
		setLocationRelativeTo(igPlanejamentoFinanceiro);
		setVisible(true);
	}
	
	/**
	 * Atualiza o gr�fico no painel.
	 */
	private void atualizaGrafico(){
		boolean porcentagem;
		if(graficoValorRadio.isSelected())
			porcentagem = false;
		else
			porcentagem = true;
		//Remove todos os Componentes do Painel.
		panelGraficoMetaMesal.removeAll();
		
		//Adiciona um novo componente
		panelGraficoMetaMesal.add(geraGraficoCategoria.geraGraficoBarra(
				mesAnoComboBox.getItemAt(mesAnoComboBox.getSelectedIndex()), porcentagem));
		
		//Revalida o painel.
		panelGraficoMetaMesal.revalidate();
		
		//Repinta o painel.
		panelGraficoMetaMesal.repaint();
	}

	/**Retorna a refer�cia do botton radio.
	 * @return um <code>JRadioButton</code>.
	 */
	public JRadioButton getGraficoValorRadio() {
		return graficoValorRadio;
	}
	
	
}
