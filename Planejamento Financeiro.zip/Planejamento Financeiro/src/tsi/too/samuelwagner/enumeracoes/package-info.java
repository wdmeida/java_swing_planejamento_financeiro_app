/**
 * Este pacote cont�m as enumera��es que s�o utilizadas pelo aplicativo de Planejamento Financeiro.
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.enumeracoes;
