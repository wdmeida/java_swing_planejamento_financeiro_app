/**
 * Este pacote cont�m as classes respons�veis por tratar os eventos das janelas do aplicativo Planejamento Financeiro.
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.trataeventos;