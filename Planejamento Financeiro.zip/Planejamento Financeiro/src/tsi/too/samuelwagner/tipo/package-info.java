/**
 * Este pacote cont�m as classes base utilizadas pelo o Planejamento Financeiro.
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.tipo;
