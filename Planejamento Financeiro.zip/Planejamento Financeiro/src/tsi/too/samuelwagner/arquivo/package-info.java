/**
 * Este pacote cont�m os arquivos utilizados para persist�ncia dos dados do aplicativo de Planejamento Financeiro.
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.arquivo;
