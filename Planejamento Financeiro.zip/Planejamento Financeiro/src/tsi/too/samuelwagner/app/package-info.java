/**
 * Este pacote possui a classe principal com o m�todo respos�vel por executar o aplicativo Planejamento Financeiro.
 * 
 * @author Samuel Gon�alves
 * @author Wagner Almeida
 */
package tsi.too.samuelwagner.app;